package com.example.exam.exception;

public class BadRequest extends RuntimeException {
    public BadRequest (String message){
        super(message);
    }
}
