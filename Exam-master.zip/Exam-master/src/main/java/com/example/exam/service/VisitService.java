package com.example.exam.service;

import com.example.exam.exception.BadRequest;
import com.example.exam.model.Visit;
import com.example.exam.repository.VisitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;


@Service
public class VisitService {
    @Autowired
    private VisitRepository visitRepository;
    @Autowired
    private DoctorService doctorService;
    @Autowired
    private PatientService patientService;

    public Visit get(Integer id) {
        return getEntity(id);
    }

    public Visit getEntity(Integer id) {
        Optional<Visit> optional = visitRepository.findById(id);
        if (optional.isEmpty()) {
            throw new BadRequest("User not found");
        }
        return optional.get();
    }

    public Visit create(Visit dto) {
        dto.setStatus(true);
        dto.setCreatedAt(LocalDateTime.now());
        return dto;
    }

    public Visit update(Integer id, Visit visit) {
        Visit oldVisit = getEntity(id);
        oldVisit.setId();

        return v;
    }


    public Visit delete(Integer id) {
        Visit visit = getEntity(id);
        visitRepository.save(visit);
        return visit;
    }

}
