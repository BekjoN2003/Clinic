package com.example.exam.service;

import com.example.exam.exception.BadRequest;
import com.example.exam.model.Patient;
import com.example.exam.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Service
public class PatientService {
    @Autowired
    private PatientRepository patientRepository;


    public Patient getEntity(Integer id){
        Optional<Patient> optional = patientRepository.findById(id);
        if (optional.isEmpty()) {
            throw new BadRequest("User not found");
        }
        return optional.get();
    }

    public Patient getPat(Integer id) {
        return getEntity(id);
    }

    public Patient createPat(Patient patient) {
        patient.setCreatedAt(LocalDateTime.now());
        patient.setStatus(true);
        return patient;
    }

    public Patient updatePat(Integer id, Patient patient) {
        Patient oldPatent= getEntity(id);
        oldPatent.setCreatedAt(patient.getCreatedAt());
        oldPatent.setBirthday(patient.getBirthday());
        oldPatent.setContact(patient.getContact());
        oldPatent.setId(patient.getId());
        oldPatent.setName(patient.getName());
        oldPatent.setSurname(patient.getSurname());
        oldPatent.setAge(patient.getAge());
        return oldPatent;
    }

    public Patient deletePat(Integer id) {
        Patient patient = getEntity(id);
        patientRepository.delete(patient);
        return patient;
    }

    public List<Patient> getAllPat(Integer size, Integer page) {
        PageRequest pageRequest = PageRequest.of(page, size);

        Page<Patient> patientPage = patientRepository.findAll(pageRequest);

        List<Patient> patientList = new LinkedList<>();
        for (Patient p: patientPage) {
            patientList.add(p);
        }
        return patientList;
    }

}
