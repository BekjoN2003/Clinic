package com.example.exam.service;

import com.example.exam.exception.BadRequest;
import com.example.exam.model.Doctor;
import com.example.exam.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;


@Service
@Component
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public Doctor getDoc(Integer id) {
        return getEntity(id);
    }

    public Doctor createDoc(Doctor dto) {
        dto.setCreatedAt(LocalDateTime.now());
        dto.setStatus(true);
        doctorRepository.save(dto);
        return dto;
    }


    public Doctor updateDoc(Integer id, Doctor doctor) {
        Doctor doctor1 = getEntity(id);
        doctor1.setName(doctor.getName());
        doctor1.setSurname(doctor.getSurname());
        doctor1.setContact(doctor.getContact());
        doctor1.setDirection(doctor.getDirection());
        doctorRepository.save(doctor1);
        return doctor1;
    }

    public Doctor deleteDoc(Integer id) {
        Doctor doctor = getEntity(id);
        doctorRepository.save(doctor);
        return doctor;
    }

    public Doctor getEntity(Integer id) {
        Optional<Doctor> optional =doctorRepository.findById(id);
        if(optional.isEmpty()){
            throw new BadRequest("Doctor not fount");
        }
        return optional.get();
    }




}
