package com.example.exam.exception;

public class BadRequest {
}
